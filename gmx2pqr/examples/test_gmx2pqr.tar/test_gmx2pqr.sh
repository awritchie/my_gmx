#! /bin/bash

default="CHANGE THE gmx2pqr VARIABLE TO POINT TO THE INSTALLATION PATH"
gmx2pqr=$default

if [ "$gmx2pqr" == "$default" ] ; then echo $default ; exit ; fi
if [ ! -s $gmx2pqr ] ; then echo $default ; echo "The defined $gmx2pqr does not exist or is empty" ; exit ; fi

gro=gro.gro
tpr=tpr.tpr
out=test_field.xvg
ref=ref_field.xvg
rm -f $out

CD=`grep "CNC" $gro | grep CD | awk '{print $3}'`
NE=`grep "CNC" $gro | grep NE | awk '{print $3}'`
SG=`grep "CNC" $gro | grep SG | awk '{print $3}'`
CB=`grep "CNC" $gro | grep CB | awk '{print $3}'`
HB1=`grep "CNC" $gro | grep HB1 | awk '{print $3}'`
HB2=`grep "CNC" $gro | grep HB2 | awk '{print $3}'`

./$gmx2pqr \
-s $tpr \
-f $gro \
-of $out \
-a1 $CD \
-a2 $NE \
-exclude "$SG $CB $HB1 $HB2" \
-select "(not resname SOL and not name Na)"  \
-nodopqr \
-xvg none

# -a1       Atom index of starting atom of probe bond vector
# -a2       Atom index of ending atom of probe bond vector
# -exclude  Atom indices of any atoms which should have their
#           field contributions calculated and removed from
#           the total field; ie, removing the probe self-field
# -select   String selection of atoms to include in the field.
#           This is very fast at selecting--must faster than
#           using an index file, especially for the removal
#           of a very large number of atoms, such as all
#           solvent.  For example, I've used this to select
#           for solute as well as all water molecules
#           within the first hydration shell of the probe.
# -nodopqr  You don't want to generate a ton of .pqr files
#           for running APBS
# -xvg      Using none for convenience when comparing the
#           output field file with the reference field file

echo
if diff $out $ref >/dev/null ; then
    echo "The reference and the output are the same."
else
    echo "The reference and the output are different. That means there is a coding bug"
    echo "somewhere that should be fixed..."
fi